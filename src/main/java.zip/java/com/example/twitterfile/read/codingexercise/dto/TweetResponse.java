package com.example.twitterfile.read.codingexercise.dto;

public class TweetResponse {
}
